using UnityEngine;

public class DestroyFruit : MonoBehaviour
{
    // Start is called before the first frame update
    private void Start()
    {
        Invoke("destroyFruit", 4f);
    }

    private void destroyFruit()
    {
        Destroy(gameObject);
    }
}