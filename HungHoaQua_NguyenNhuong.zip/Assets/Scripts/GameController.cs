using TMPro;
using UnityEngine;

public class GameController : MonoBehaviour
{
    public GameObject[] FruitArr;

    //public GameObject[] FruitAdd;
    public float spawnTime;

    private float m_spawmTime;
    public int m_score;
    private bool m_isGameOver;
    public int live = 5;

    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI liveText;

    public GameObject gameOver;

    private void Start()
    {
        m_spawmTime = 0;
        scoreText.text = "Score: ";
        liveText.text = "Live: 5 ";
    }

    private void Update()
    {
        m_spawmTime -= Time.deltaTime;
        if (m_isGameOver == true)
        {
            m_spawmTime = 0;
            return;
        }
        if (m_spawmTime <= 0)
        {
            SpawnFruit();
            m_spawmTime = spawnTime;
        }
        if (live == 0)
        {
            Time.timeScale = 0;
            gameOver.SetActive(true);
        }
    }

    public void SpawnFruit()
    {
        Vector2 spawnPos = new Vector2(Random.Range(-6, 4), Random.Range(3, 4));
        int randomnumber = Random.Range(0, FruitArr.Length);
        if (FruitArr[randomnumber])
        {
            Instantiate(FruitArr[randomnumber], spawnPos, Quaternion.identity);
        }
    }

    public void SetScore(int value)
    {
        m_score = value;
    }

    public int GetScore()
    {
        return m_score;
    }

    public void SetLive(int value)
    {
        this.live = value;
    }

    public int GetLive()
    {
        return live;
    }

    public void IncrementScore()
    {
        m_score++;
    }

    public void IncrementLive()
    {
        live--;
    }

    public bool IsGameOver()
    {
        return m_isGameOver;
    }

    public void SetGameOverState(bool state)
    {
        m_isGameOver = state;
    }
}