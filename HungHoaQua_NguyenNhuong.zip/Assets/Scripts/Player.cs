﻿using DG.Tweening;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float moveSpeed;
    private float xDirection;

    [SerializeField]
    private GameController m_gc;

    [SerializeField] private SpriteRenderer sprite;

    private void Start()
    {
        m_gc = FindObjectOfType<GameController>();
    }

    private void Update()
    {
        xDirection = Input.GetAxisRaw("Horizontal");
        float moveStep = moveSpeed * xDirection * Time.deltaTime;
        if ((transform.position.x <= -9f && xDirection < 0) || (transform.position.x >= 9f && xDirection > 0))
            return;
        transform.position = transform.position + new Vector3(moveStep, 0, 0);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Fruit"))
        {
            Destroy(collision.gameObject);
            m_gc.IncrementScore();
            m_gc.scoreText.text = "Score: " + m_gc.m_score.ToString();
            //ollision.gameObject.SetActive(false);
        }
        if (collision.gameObject.CompareTag("Enemies"))
        {
            m_gc.IncrementLive();
            sprite.DOFade(0, 0.1f).SetLoops(20).OnComplete(() =>
            {
                sprite.DOFade(1, 0.25f).OnComplete(() =>
                {
                });
            });
            Destroy(collision.gameObject);
            m_gc.liveText.text = "Live: " + m_gc.live.ToString();
        }
    }
}

/*
 - Dung panel 
- check live = 0

 */