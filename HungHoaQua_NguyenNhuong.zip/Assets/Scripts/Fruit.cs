using UnityEngine;

public class Fruit : MonoBehaviour
{
    private void Start()
    {
    }

    private void OnCollisionEnter2D(Collision2D col)
    {
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
    }
}